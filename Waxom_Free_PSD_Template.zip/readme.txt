Waxom - Free Homepage PSD Template.

Fonts Used:
Raleway https://www.google.com/fonts/specimen/Raleway
Montserrat https://www.google.com/fonts/specimen/Montserrat
Roboto https://www.google.com/fonts/specimen/Roboto

Icons Used: http://www.flaticon.com/
Free Photo Used: https://pixabay.com/

------------------------

Waxom - Clean & Universal PSD Template (230 psd's files) Download: http://themeforest.net/item/waxom-clean-universal-psd-template/8407963
Waxom - Clean & Universal WordPress Theme http://themeforest.net/item/waxom-clean-universal-wordpress-theme/13639831

------------------------

Thank you for the attention and have a nice day ;)

Regards, 
Dmitry (themefire).